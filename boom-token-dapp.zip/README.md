# Boom Token DApp

A decentralized application (DApp) for **Boom Token** on Binance Smart Chain (BSC), built with **React, @usedapp/core, and Vite**.

## Features

✅ Wallet Connection (MetaMask, Boom Wallet)  
✅ Display BOOM Token Balance  
✅ Send BOOM Transactions  
✅ Uses Binance Virtual RPC from Tenderly  

## Setup & Deployment

### Install Dependencies
```sh
npm install
```

### Start Development Server
```sh
npm run dev
```

### Build for Production
```sh
npm run build
```

## License
MIT
