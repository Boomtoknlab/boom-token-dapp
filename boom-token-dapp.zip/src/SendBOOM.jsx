import React, { useState } from "react";
import { useSendTransaction } from "@usedapp/core";
import { utils } from "ethers";

const SendBOOM = () => {
  const { sendTransaction } = useSendTransaction();
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");

  const sendBoom = () => {
    sendTransaction({
      to: recipient,
      value: utils.parseEther(amount),
    });
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Recipient Address"
        value={recipient}
        onChange={(e) => setRecipient(e.target.value)}
      />
      <input
        type="text"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <button onClick={sendBoom}>Send BOOM</button>
    </div>
  );
};

export default SendBOOM;
