import React from "react";
import { useEthers } from "@usedapp/core";

const ConnectWallet = () => {
  const { activateBrowserWallet, account } = useEthers();

  return (
    <div>
      {account ? (
        <p>Connected: {account}</p>
      ) : (
        <button onClick={activateBrowserWallet}>Connect Wallet</button>
      )}
    </div>
  );
};

export default ConnectWallet;
