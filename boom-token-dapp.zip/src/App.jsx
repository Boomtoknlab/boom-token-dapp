import React from "react";
import ConnectWallet from "./ConnectWallet";
import TokenBalance from "./TokenBalance";
import SendBOOM from "./SendBOOM";

const App = () => {
  return (
    <div>
      <h1>Boom Token DApp</h1>
      <ConnectWallet />
      <TokenBalance />
      <SendBOOM />
    </div>
  );
};

export default App;
