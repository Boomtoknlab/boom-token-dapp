import React from "react";
import ReactDOM from "react-dom/client";
import { DAppProvider, Config, BSC } from "@usedapp/core";
import App from "./App";

const config = {
  networks: [BSC],
  readOnlyChainId: BSC.chainId,
  readOnlyUrls: {
    [BSC.chainId]: "https://virtual.binance.rpc.tenderly.co/add95b93-f1d4-4d71-a63d-0e89712c101d",
  },
};

ReactDOM.createRoot(document.getElementById("root")).render(
  <DAppProvider config={config}>
    <App />
  </DAppProvider>
);
