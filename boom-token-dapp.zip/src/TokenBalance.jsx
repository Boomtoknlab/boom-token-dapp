import React from "react";
import { useEthers, useTokenBalance } from "@usedapp/core";

const BOOM_TOKEN_ADDRESS = "0xcd6a51559254030ca30c2fb2cbdf5c492e8caf9c"; // BOOM Token (BSC)

const TokenBalance = () => {
  const { account } = useEthers();
  const balance = useTokenBalance(BOOM_TOKEN_ADDRESS, account);

  return <p>BOOM Balance: {balance ? balance.toString() : "0"}</p>;
};

export default TokenBalance;
